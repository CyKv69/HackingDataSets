install.packages("stringr")
require(stringr)

excel_data = "C:\PFDA Assignment\hackingData.csv"

df = read.csv(excel_data)
df

# check data types of all columns
str(df)

# check summary
summary(df)

#to lowercase the column names
names(df) = tolower(names(df))
df

#check how many NAs in dataset
colSums(is.na(df))
View(df)

# Convert spaces to NA
df$ip = replace(df$ip, df$ip =="", NA)
df$country = replace(df$country, df$country =="", NA)
df$webserver = replace(df$webserver, df$webserver =="", NA)
df$lang = replace(df$lang, df$lang =="", NA)
df$country = replace(df$country, df$country =="UNKNOWN", NA)
df$os = replace(df$os, df$os =="Unknown", NA)
df$webserver = replace(df$webserver, df$webserver =="Unknown", NA)



#Convert Null to NA
df$encoding = replace(df$encoding, df$encoding =="NULL", NA)
df$lang = replace(df$lang, df$lang =="NULL", NA)

colSums(is.na(df))
View(df)

# create delete.na function to remove rows
delete.na <- function(DF, n = 0){
  DF[rowSums(is.na(DF)) <= n,]
}

# delete rows that NA more than 5
df = delete.na(df, 5)
View(df)

# reset row index number
row.names(df) = NULL
View(df)


df$country = str_to_title(df$country)
View(df)
